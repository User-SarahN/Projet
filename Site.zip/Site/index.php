<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les valeurs soumises par le formulaire
    $username = $_POST['username'];
    $password = $_POST['pass'];

    // Établir une connexion à la base de données
    $servername = "localhost";
    $usernameDB = "root";
    $passwordDB = "";
    $dbname = "darties";

    $conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

    // Vérifier si la connexion a échoué
    if ($conn->connect_error) {
        die("Erreur de connexion à la base de données : " . $conn->connect_error);
    }

    // Échapper les valeurs pour éviter les injections SQL
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // Exécuter la requête pour vérifier les informations d'identification
    $query = "SELECT * FROM Utilisateurs WHERE nom_utilisateur = '$username' AND mot_de_passe = '$password'";
    $result = $conn->query($query);

    // Vérifier si l'utilisateur existe
    if ($result->num_rows == 1) {
        // Authentification réussie
        // Obtenir le rôle de l'utilisateur à partir de la base de données
        //Redirection vers le Tableau de bord
        header("Location: dashboard_role.php?role=".$username);
    } else {
        // Authentification échouée
        $error = "Nom d'utilisateur ou mot de passe incorrect.";
    }

    // Fermer la connexion à la base de données
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DARTIES</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <link rel="stylesheet" href="./style.css">
    <link rel="shortcut icon" href="darties_logo.png" type="image/png">

    <style>
        .main-bg{
            background-color: #FFFFFF;
        }

        #dashboard-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>
</head>

<body>
    <div class="main-bg">
        <div class="box-conatiner">
            <div class="row">
                <div class="col-md-6 col-sm-6">

                </div>
                <div class="col-sm-6 col-md-6">
                    <div class="wrap-login100">
                        <span class="login100-form-title">
                            <img class="col-sm-3" src="darties_logo.png" alt="logo">
                        </span>
                        <form class="login100-form validate-form p-l-55 p-r-55 p-t-20" method="POST">

                            <div class="wrap-input100 validate-input m-b-16" data-validate="Veuillez saisir votre nom d'utilisateur">
                                <input class="input100" type="text" name="username" placeholder="Nom d'utilisateur">
                                <span class="focus-input100"></span>
                            </div>

                            <div class="wrap-input100 validate-input" data-validate="Veuillez saisir votre mot de passe">
                                <input class="input100" type="password" name="pass" placeholder="Mot de passe">
                                <span class="focus-input100"></span>
                            </div>
                            
                            <div class="text-right p-t-13 p-b-23">
                                
                            </div>

                            <div class="container-login100-form-btn">
                                <button class="login100-form-btn" type="submit">
                                    Connexion
                                </button>

                                <?php if (isset($error)): ?>
                                    <div class="text-danger"><?php echo "ATTENTION : ".$error; ?></div>
                                <?php endif; ?>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
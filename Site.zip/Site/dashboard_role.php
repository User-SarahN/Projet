<?php 
    $user_role=$_GET['role'];
    if ($user_role == "directeur_comm") {
        $role="Directeur commerciale";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=c789942d-6ae5-4ed4-ab28-d43972138a7c&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    } elseif ($user_role == "responsable_sud_est") {
        $role="Responsable Sud Est";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=cd7c2978-deda-4b28-bfef-273d885b1add&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    } elseif ($user_role == "responsable_nord_est") {
        $role="Responsable Nord Est";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=f30d4536-d1b0-41ba-a389-860f279ca4ec&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_nord_ouest") {
        $role="Responsable Nord Ouest";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=534f5926-4656-47b8-a4d6-a87bd957728d&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_sud_ouest") {
        $role="Responsable Sud Ouest";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=05bb1721-c0fa-4671-8d78-4ed15cb8b040&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_paris") {
        $role="Responsable région Parisienne";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=f7781e44-7e2f-427e-9f60-4f323ff40c07&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_boulanger") {
        $role="Responsable Boulanger";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=678f99a6-c907-4545-a854-23c081e5b9fc&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_darty") {
        $role="Responsable Darty";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=ec1dc989-046a-48c9-a2e9-bbe3f5e45dc6&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }elseif ($user_role == "responsable_leroy_merlin") {
        $role="Responsable Leroy Merlin";
        $iframe_src="https://app.powerbi.com/reportEmbed?reportId=b7d9d2e6-b98a-4c0e-8dfa-ded01e1e1f03&autoAuth=true&ctid=654b4463-2e7e-4dee-b5b1-c828bfd6195e&navContentPaneEnabled=false";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord - <?php echo $role; ?></title>
    <link rel="shortcut icon" href="darties_logo.png" type="image/png">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    
    <style>
        body {
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        #dashboard-container {
            width: 95%;
            height: 90vh;
            max-width: 1200px;
            margin: 0 auto;
        }

        iframe {
            width: 100%;
            height: 100%;
        }

</style>
</head>

<body>
    <div id="dashboard-container">
        <iframe title="TDB Darties" width="1140" height="541.25" src="<?php echo $iframe_src; ?>" frameborder="0" allowFullScreen="true"></iframe>
        </br>
        <div class="mt-1">
            <a class="btn btn-danger" href="index.php">Déconnexion</a>
        </div>

    </div>
</body>
</html>
